import torch
import cv2
from torchvision import models, transforms
import torch.nn as nn

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

classes = [
    "apple", "avocado", "banana", "coconut", "mango",
    "pineaple", "strawberry"
]

model = models.mobilenet_v2(pretrained=False)
model.classifier[1] = nn.Linear(model.last_channel, 7)
model.load_state_dict(torch.load("saved_model/fruit_model.pth", map_location=DEVICE))
model.eval()
model.to(DEVICE)

transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225])
])

img = cv2.imread("pomme.png")
img = transform(img).unsqueeze(0).to(DEVICE)

with torch.no_grad():
    outputs = model(img)
    probs = torch.softmax(outputs, dim=1)
    confidence, pred = torch.max(probs, 1)

print("Fruit reconnu :", classes[pred.item()])
print("Confiance :", round(confidence.item() * 100, 2), "%")
